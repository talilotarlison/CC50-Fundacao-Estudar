-- Keep a log of any SQL queries you execute as you solve the mystery.

